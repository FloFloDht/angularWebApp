// -*- coding: utf-8 -*-

public class BlancheNeige {
    public Nain sAssocier() throws InterruptedException {
        return (Nain) Thread.currentThread();            
    }

    public void seSéparer(){
    }
}

