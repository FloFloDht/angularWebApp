// -*- coding: utf-8 -*-

import java.util.Random;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Nain extends Thread {
    private static BlancheNeige bn = new BlancheNeige();

    public Nain(String nom){
        this.setName(nom);
    }
  
    private String dateEtNom() {
        final SimpleDateFormat sdf = new SimpleDateFormat("hh'h 'mm'mn 'ss','SSS's'");  
        Date maDate = new Date(System.currentTimeMillis());
        return "[ "+sdf.format(maDate)+" ] " + getName();
    }
  
    public void run(){
        try {
            Random aléa = new Random();
            sleep(1000 + aléa.nextInt(2000));
            System.out.println(dateEtNom() + " veut danser.");
            Nain partenaire = bn.sAssocier();
            if ( partenaire == null ) {
                System.out.println(dateEtNom() + " ne dansera pas ce soir!");
            } else {
                System.out.println(dateEtNom() + " danse avec " + partenaire.getName());
                sleep(3000);
                System.out.println(dateEtNom() + " quitte " + partenaire.getName());
                bn.seSéparer();
            }
        } catch (InterruptedException e) { e.printStackTrace(); }
    }
}

