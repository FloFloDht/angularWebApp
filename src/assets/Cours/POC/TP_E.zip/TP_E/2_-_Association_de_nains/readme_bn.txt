Placez ici une trace de la compilation et de l'exécution des programmes.

