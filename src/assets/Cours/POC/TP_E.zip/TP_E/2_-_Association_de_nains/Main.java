// -*- coding: utf-8 -*-

public class Main {
    public static void main(String[] args) {
        int nbNains=7;
        String nom[] = {"Simplet", "Dormeur", "Atchoum", "Joyeux",
                    "Grincheux", "Prof", "Timide"};
        Nain nain[] = new Nain [nbNains];
        for(int i = 0; i < nbNains; i++) {
            nain[i] = new Nain(nom[i]);
            nain[i].start();
        }
    }    
}

