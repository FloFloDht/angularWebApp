// -*- coding: utf-8 -*-

import java.util.Random ;

public class Inversions {
    static final int taille = 100_000 ;                          
    static final int [] tableau = new int[taille] ;  // Tableau de la taille voulue
    static final int borne = 10 * taille ;           // Valeur maximale dans le tableau

    private static long nbInversions() {
        long résultat = 0;
        for (int i = 0; i < taille-1; i++) {
            for (int j = i+1; j < taille; j++) {
                if ( tableau[i] > tableau[j] ) résultat++;
            }
        }
        return résultat;
    }

    public static void main(String[] args) {
        Random aléa = new Random() ;
        for (int i=0 ; i<taille ; i++) {              // Remplissage aléatoire du tableau
            tableau[i] = aléa.nextInt(2*borne) - borne ;            
        }
        System.out.println("Taille du tableau choisi = " + taille) ;

        long début1 = System.nanoTime() ;
        long résultat1 = nbInversions() ;
        long fin1 = System.nanoTime() ;
        long durée1 = (fin1 - début1) / 1_000_000 ;
        System.out.print("Nb d'inversions = " + résultat1) ;
        System.out.println(" obtenu en " + durée1 + " ms en séquentiel.") ;

        // À COMPLÉTER ICI !
    }
}


/*
  $ javac Inversions.java
  $ java Inversions
  Taille du tableau choisi = 100000
  Nb d'inversions = 2502243250 obtenu en 5519 ms en séquentiel.
  $
  $
*/
