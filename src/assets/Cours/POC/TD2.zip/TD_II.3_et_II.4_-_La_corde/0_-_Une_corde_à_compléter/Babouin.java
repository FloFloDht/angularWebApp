class Corde {                    // À COMPLÉTER

    public void saisir(Côté origine){
    }

    public void lâcher(Côté origine){
	}
}

enum Côté { EST, OUEST }               // Le canyon possède un côté EST et un côté OUEST

class Babouin extends Thread {
    static Corde corde = new Corde();  // Corde commune utilisée par tous les babouins
    Côté origine;                      // Côté du canyon où apparaît le babouin: EST ou OUEST

    Babouin(Côté origine, int i) {     // Constructeur de la classe Babouin
        this.origine = origine;          // Chaque babouin apparaît d'un côté précis du canyon
        if (origine == Côté.EST) setName("E"+i);
        else setName("O"+i);
    }  

    public void run() {
        System.out.println("Le babouin " + getName() + " arrive sur le côté " + origine);
        corde.saisir(origine);           // Pour traverser, le babouin saisit la corde
        System.out.println("\t Le babouin " + getName() + " commence à traverser.");
        try { sleep(5000); } catch(InterruptedException e){e.printStackTrace();}
        // La traversée ne dure que 5 secondes
        System.out.println("\t\t Le babouin " + getName() + " a terminé sa traversée.");
        corde.lâcher(origine);           // Arrivé de l'autre côté, le babouin lâche la corde
        System.out.println("\t\t\t Le babouin " + getName() + " a lâché la corde et s'en va.");
    }

    public static void main(String[] args) { 
        for (int i = 1; i < 20; i++){
            try { Thread.sleep(2000); } catch(InterruptedException e){e.printStackTrace();}
            if (Math.random() >= 0.5)  new Babouin(Côté.EST, i).start();
            else new Babouin(Côté.OUEST, i).start();
        } // Une vingtaine de babouins sont répartis sur les deux côtés du canyon
    }
}
