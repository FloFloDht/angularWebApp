// -*- coding: utf-8 -*-

import java.util.ArrayList;

class Corde {
    private int nbEntreesOuest = 0;
    private int nbEntreesEst = 0;
    private ArrayList<Babouin> file = new ArrayList<Babouin>() ;

    
    public synchronized void saisir(Côté origine){
        Babouin courant = (Babouin) Thread.currentThread() ;
        file.add(courant);
        if (origine == Côté.EST) {
            while (!file.get(0).equals(courant) || (nbEntreesOuest > 0) || (nbEntreesEst >= 5)){
                try { wait(); } catch(InterruptedException e) {e.printStackTrace();}
            }
            nbEntreesEst = nbEntreesEst + 1;
        } else {
            while (!file.get(0).equals(courant) || (nbEntreesEst > 0) || (nbEntreesOuest >= 5)){
                try { wait(); } catch(InterruptedException e) {e.printStackTrace();}
            }
            nbEntreesOuest = nbEntreesOuest + 1;
        }
        file.remove(0); // Au prochain!
    }

    public synchronized void lâcher(Côté origine){
	    if (origine == Côté.EST) {
            nbEntreesEst = nbEntreesEst - 1;
            notifyAll();
	    } else {
            nbEntreesOuest = nbEntreesOuest - 1;
            notifyAll();
	    }
	}
}

enum Côté { EST, OUEST }                 // Le canyon possède un côté EST et un côté OUEST

class Babouin extends Thread {
    static Corde corde = new Corde();    // Corde commune utilisée par tous les babouins
    Côté origine;                        // Côté du canyon où apparaît le babouin: EST ou OUEST

    Babouin(Côté origine, int i) {       // Constructeur de la classe Babouin
        this.origine = origine;          // Chaque babouin apparaît d'un côté précis du canyon
        if (origine == Côté.EST) setName("E"+i);
        else setName("O"+i);
    }  

    public void run() {
        System.out.println("Le babouin " + getName() + " arrive sur le côté " + origine);
        corde.saisir(origine);           // Pour traverser, le babouin saisit la corde
        System.out.println("\t Le babouin " + getName() + " commence à traverser.");
        try { sleep(5000); } catch(InterruptedException e){e.printStackTrace();}
        // La traversée ne dure que 5 secondes
        System.out.println("\t\t Le babouin " + getName() + " a terminé sa traversée.");
        corde.lâcher(origine);           // Arrivé de l'autre côté, le babouin lâche la corde
        System.out.println("\t\t\t Le babouin " + getName() + " a lâché la corde et s'en va.");
    }

    public static void main(String[] args) { 
        for (int i = 1; i < 20; i++){
            try { Thread.sleep(2000); } catch(InterruptedException e){e.printStackTrace();}
            if (Math.random() >= 0.9)  new Babouin(Côté.EST, i).start();
            else new Babouin(Côté.OUEST, i).start();
        } // Une vingtaine de babouins sont répartis sur les deux côtés du canyon
          // Avec 90% de babouins à l'Ouest!
    }
}


/*
  $ java Babouin
  Le babouin O1 arrive sur le côté OUEST
  .... Le babouin O1 commence à traverser.
  Le babouin O2 arrive sur le côté OUEST
  .... Le babouin O2 commence à traverser.
  Le babouin O3 arrive sur le côté OUEST
  .... Le babouin O3 commence à traverser.
  ........ Le babouin O1 a terminé sa traversée.
  ............ Le babouin O1 a lâché la corde et s'en va.
  Le babouin O4 arrive sur le côté OUEST
  .... Le babouin O4 commence à traverser.
  ........ Le babouin O2 a terminé sa traversée.
  ............ Le babouin O2 a lâché la corde et s'en va.
  Le babouin O5 arrive sur le côté OUEST
  .... Le babouin O5 commence à traverser.
  ........ Le babouin O3 a terminé sa traversée.
  ............ Le babouin O3 a lâché la corde et s'en va.
  Le babouin E6 arrive sur le côté EST
  ........ Le babouin O4 a terminé sa traversée.
  ............ Le babouin O4 a lâché la corde et s'en va.
  Le babouin O7 arrive sur le côté OUEST
  ........ Le babouin O5 a terminé sa traversée.
  ............ Le babouin O5 a lâché la corde et s'en va.
  .... Le babouin E6 commence à traverser.
  Le babouin O8 arrive sur le côté OUEST
  Le babouin O9 arrive sur le côté OUEST
  ........ Le babouin E6 a terminé sa traversée.
  ............ Le babouin E6 a lâché la corde et s'en va.
  .... Le babouin O7 commence à traverser.
  .... Le babouin O8 commence à traverser.
  Le babouin O10 arrive sur le côté OUEST
  Le babouin O11 arrive sur le côté OUEST
  Le babouin E12 arrive sur le côté EST
  ........ Le babouin O7 a terminé sa traversée.
  ........ Le babouin O8 a terminé sa traversée.
  .... Le babouin O10 commence à traverser.
  .... Le babouin O9 commence à traverser.
  ............ Le babouin O7 a lâché la corde et s'en va.
  .... Le babouin O11 commence à traverser.
  ............ Le babouin O8 a lâché la corde et s'en va.
  Le babouin O13 arrive sur le côté OUEST
  Le babouin O14 arrive sur le côté OUEST
  ........ Le babouin O10 a terminé sa traversée.
  ........ Le babouin O9 a terminé sa traversée.
  ............ Le babouin O10 a lâché la corde et s'en va.
  ........ Le babouin O11 a terminé sa traversée.
  ............ Le babouin O11 a lâché la corde et s'en va.
  ............ Le babouin O9 a lâché la corde et s'en va.
  .... Le babouin E12 commence à traverser.
  Le babouin O15 arrive sur le côté OUEST
  Le babouin O16 arrive sur le côté OUEST
  Le babouin O17 arrive sur le côté OUEST
  ........ Le babouin E12 a terminé sa traversée.
  ............ Le babouin E12 a lâché la corde et s'en va.
  .... Le babouin O13 commence à traverser.
  Le babouin O18 arrive sur le côté OUEST
  Le babouin O19 arrive sur le côté OUEST
  ........ Le babouin O13 a terminé sa traversée.
  ............ Le babouin O13 a lâché la corde et s'en va.
  .... Le babouin O14 commence à traverser.
  .... Le babouin O15 commence à traverser.
  .... Le babouin O17 commence à traverser.
  .... Le babouin O16 commence à traverser.
  ........ Le babouin O14 a terminé sa traversée.
  ............ Le babouin O14 a lâché la corde et s'en va.
  ........ Le babouin O15 a terminé sa traversée.
  ........ Le babouin O17 a terminé sa traversée.
  ............ Le babouin O17 a lâché la corde et s'en va.
  .... Le babouin O19 commence à traverser.
  ............ Le babouin O15 a lâché la corde et s'en va.
  ........ Le babouin O16 a terminé sa traversée.
  .... Le babouin O18 commence à traverser.
  ............ Le babouin O16 a lâché la corde et s'en va.
  ........ Le babouin O19 a terminé sa traversée.
  ............ Le babouin O19 a lâché la corde et s'en va.
  ........ Le babouin O18 a terminé sa traversée.
  ............ Le babouin O18 a lâché la corde et s'en va.
  $
*/
