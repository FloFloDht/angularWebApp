// -*- coding: utf-8 -*-


class Corde {
    private int nbEntreesOuest = 0;
    private int nbEntreesEst = 0;
   
    public synchronized void saisir(Côté origine){
        if (origine == Côté.EST) {
            while ((nbEntreesOuest > 0) || (nbEntreesEst >= 5)) {
                try { wait(); } catch(InterruptedException e) {e.printStackTrace();}
            }
            nbEntreesEst = nbEntreesEst + 1;
        } else {
            while ((nbEntreesEst > 0) || (nbEntreesOuest >= 5)) {
                try { wait(); } catch(InterruptedException e) {e.printStackTrace();}
            }
            nbEntreesOuest = nbEntreesOuest + 1;
        }
    }

    public synchronized void lâcher(Côté origine){
	    if (origine == Côté.EST) {
            nbEntreesEst = nbEntreesEst - 1;
            notifyAll();
	    } else {
            nbEntreesOuest = nbEntreesOuest - 1;
            notifyAll();
	    }
	}
}

enum Côté { EST, OUEST }                 // Le canyon possède un côté EST et un côté OUEST

class Babouin extends Thread {
    static Corde corde = new Corde();    // Corde commune utilisée par tous les babouins
    Côté origine;                        // Côté du canyon où apparaît le babouin: EST ou OUEST

    Babouin(Côté origine, int i) {       // Constructeur de la classe Babouin
        this.origine = origine;          // Chaque babouin apparaît d'un côté précis du canyon
        if (origine == Côté.EST) setName("E"+i);
        else setName("O"+i);
    }  

    public void run() {
        System.out.println("Le babouin " + getName() + " arrive sur le côté " + origine);
        corde.saisir(origine);           // Pour traverser, le babouin saisit la corde
        System.out.println("\t Le babouin " + getName() + " commence à traverser.");
        try { sleep(5000); } catch(InterruptedException e){e.printStackTrace();}
        // La traversée ne dure que 5 secondes
        System.out.println("\t\t Le babouin " + getName() + " a terminé sa traversée.");
        corde.lâcher(origine);           // Arrivé de l'autre côté, le babouin lâche la corde
        System.out.println("\t\t\t Le babouin " + getName() + " a lâché la corde et s'en va.");
    }

    public static void main(String[] args) { 
        for (int i = 1; i < 20; i++){
            try { Thread.sleep(2000); } catch(InterruptedException e){e.printStackTrace();}
            if (Math.random() >= 0.5)  new Babouin(Côté.EST, i).start();
            else new Babouin(Côté.OUEST, i).start();
        } // Une vingtaine de babouins sont répartis sur les deux côtés du canyon
    }
}


/*
  $ java Babouin
  Le babouin E1 arrive sur le côté EST
  .... Le babouin E1 commence à traverser.
  Le babouin E2 arrive sur le côté EST
  .... Le babouin E2 commence à traverser.
  Le babouin E3 arrive sur le côté EST
  .... Le babouin E3 commence à traverser.
  ........ Le babouin E1 a terminé sa traversée.
  ............ Le babouin E1 a lâché la corde et s'en va.
  Le babouin E4 arrive sur le côté EST
  .... Le babouin E4 commence à traverser.
  ........ Le babouin E2 a terminé sa traversée.
  ............ Le babouin E2 a lâché la corde et s'en va.
  Le babouin O5 arrive sur le côté OUEST
  ........ Le babouin E3 a terminé sa traversée.
  ............ Le babouin E3 a lâché la corde et s'en va.
  Le babouin O6 arrive sur le côté OUEST
  ........ Le babouin E4 a terminé sa traversée.
  ............ Le babouin E4 a lâché la corde et s'en va.
  .... Le babouin O6 commence à traverser.
  .... Le babouin O5 commence à traverser.
  Le babouin O7 arrive sur le côté OUEST
  .... Le babouin O7 commence à traverser.
  Le babouin O8 arrive sur le côté OUEST
  .... Le babouin O8 commence à traverser.
  ........ Le babouin O6 a terminé sa traversée.
  ............ Le babouin O6 a lâché la corde et s'en va.
  ........ Le babouin O5 a terminé sa traversée.
  ............ Le babouin O5 a lâché la corde et s'en va.
  Le babouin E9 arrive sur le côté EST
  ........ Le babouin O7 a terminé sa traversée.
  ............ Le babouin O7 a lâché la corde et s'en va.
  Le babouin E10 arrive sur le côté EST
  ........ Le babouin O8 a terminé sa traversée.
  ............ Le babouin O8 a lâché la corde et s'en va.
  .... Le babouin E9 commence à traverser.
  .... Le babouin E10 commence à traverser.
  Le babouin O11 arrive sur le côté OUEST
  Le babouin E12 arrive sur le côté EST
  .... Le babouin E12 commence à traverser.
  ........ Le babouin E9 a terminé sa traversée.
  ........ Le babouin E10 a terminé sa traversée.
  ............ Le babouin E9 a lâché la corde et s'en va.
  ............ Le babouin E10 a lâché la corde et s'en va.
  Le babouin O13 arrive sur le côté OUEST
  Le babouin O14 arrive sur le côté OUEST
  ........ Le babouin E12 a terminé sa traversée.
  ............ Le babouin E12 a lâché la corde et s'en va.
  .... Le babouin O11 commence à traverser.
  .... Le babouin O13 commence à traverser.
  .... Le babouin O14 commence à traverser.
  Le babouin O15 arrive sur le côté OUEST
  .... Le babouin O15 commence à traverser.
  Le babouin O16 arrive sur le côté OUEST
  .... Le babouin O16 commence à traverser.
  ........ Le babouin O14 a terminé sa traversée.
  ............ Le babouin O14 a lâché la corde et s'en va.
  ........ Le babouin O13 a terminé sa traversée.
  ........ Le babouin O11 a terminé sa traversée.
  ............ Le babouin O11 a lâché la corde et s'en va.
  Le babouin O17 arrive sur le côté OUEST
  ............ Le babouin O13 a lâché la corde et s'en va.
  .... Le babouin O17 commence à traverser.
  ........ Le babouin O15 a terminé sa traversée.
  ............ Le babouin O15 a lâché la corde et s'en va.
  Le babouin E18 arrive sur le côté EST
  ........ Le babouin O16 a terminé sa traversée.
  ............ Le babouin O16 a lâché la corde et s'en va.
  Le babouin E19 arrive sur le côté EST
  ........ Le babouin O17 a terminé sa traversée.
  ............ Le babouin O17 a lâché la corde et s'en va.
  .... Le babouin E18 commence à traverser.
  .... Le babouin E19 commence à traverser.
  ........ Le babouin E18 a terminé sa traversée.
  ........ Le babouin E19 a terminé sa traversée.
  ............ Le babouin E18 a lâché la corde et s'en va.
  ............ Le babouin E19 a lâché la corde et s'en va.
  $
*/


/* Une exécution un peu inéquitable
  $ java Babouin
  Le babouin O1 arrive sur le côté OUEST
  .... Le babouin O1 commence à traverser.
  Le babouin E2 arrive sur le côté EST
  Le babouin O3 arrive sur le côté OUEST
  .... Le babouin O3 commence à traverser.
  ........ Le babouin O1 a terminé sa traversée.
  ............ Le babouin O1 a lâché la corde et s'en va.
  Le babouin O4 arrive sur le côté OUEST
  .... Le babouin O4 commence à traverser.
  Le babouin O5 arrive sur le côté OUEST
  .... Le babouin O5 commence à traverser.
  ........ Le babouin O3 a terminé sa traversée.
  ............ Le babouin O3 a lâché la corde et s'en va.
  Le babouin O6 arrive sur le côté OUEST
  .... Le babouin O6 commence à traverser.
  ........ Le babouin O4 a terminé sa traversée.
  ............ Le babouin O4 a lâché la corde et s'en va.
  Le babouin O7 arrive sur le côté OUEST
  .... Le babouin O7 commence à traverser.
  ........ Le babouin O5 a terminé sa traversée.
  ............ Le babouin O5 a lâché la corde et s'en va.
  Le babouin O8 arrive sur le côté OUEST
  .... Le babouin O8 commence à traverser.
  ........ Le babouin O6 a terminé sa traversée.
  ............ Le babouin O6 a lâché la corde et s'en va.
  Le babouin O9 arrive sur le côté OUEST
  .... Le babouin O9 commence à traverser.
  ........ Le babouin O7 a terminé sa traversée.
  ............ Le babouin O7 a lâché la corde et s'en va.
  Le babouin O10 arrive sur le côté OUEST
  .... Le babouin O10 commence à traverser.
  ........ Le babouin O8 a terminé sa traversée.
  ............ Le babouin O8 a lâché la corde et s'en va.
  Le babouin O11 arrive sur le côté OUEST
  .... Le babouin O11 commence à traverser.
  ........ Le babouin O9 a terminé sa traversée.
  ............ Le babouin O9 a lâché la corde et s'en va.
  Le babouin O12 arrive sur le côté OUEST
  .... Le babouin O12 commence à traverser.
  ........ Le babouin O10 a terminé sa traversée.
  ............ Le babouin O10 a lâché la corde et s'en va.
  Le babouin O13 arrive sur le côté OUEST
  .... Le babouin O13 commence à traverser.
  ........ Le babouin O11 a terminé sa traversée.
  ............ Le babouin O11 a lâché la corde et s'en va.
  Le babouin E14 arrive sur le côté EST
  ........ Le babouin O12 a terminé sa traversée.
  ............ Le babouin O12 a lâché la corde et s'en va.
  Le babouin E15 arrive sur le côté EST
  ........ Le babouin O13 a terminé sa traversée.
  ............ Le babouin O13 a lâché la corde et s'en va.
  .... Le babouin E2 commence à traverser.
  .... Le babouin E14 commence à traverser.
  .... Le babouin E15 commence à traverser.
  Le babouin O16 arrive sur le côté OUEST
  Le babouin O17 arrive sur le côté OUEST
  ........ Le babouin E15 a terminé sa traversée.
  ........ Le babouin E14 a terminé sa traversée.
  ........ Le babouin E2 a terminé sa traversée.
  ............ Le babouin E14 a lâché la corde et s'en va.
  ............ Le babouin E15 a lâché la corde et s'en va.
  .... Le babouin O17 commence à traverser.
  Le babouin O18 arrive sur le côté OUEST
  .... Le babouin O18 commence à traverser.
  .... Le babouin O16 commence à traverser.
  ............ Le babouin E2 a lâché la corde et s'en va.
  Le babouin O19 arrive sur le côté OUEST
  .... Le babouin O19 commence à traverser.
  ........ Le babouin O17 a terminé sa traversée.
  ............ Le babouin O17 a lâché la corde et s'en va.
  ........ Le babouin O18 a terminé sa traversée.
  ........ Le babouin O16 a terminé sa traversée.
  ............ Le babouin O18 a lâché la corde et s'en va.
  ............ Le babouin O16 a lâché la corde et s'en va.
  ........ Le babouin O19 a terminé sa traversée.
  ............ Le babouin O19 a lâché la corde et s'en va.
  $
*/
