// -*- coding: utf-8 -*-

import java.util.Random;

public class Diner {    
    public static void main(String[] argv){
        Fourchette f[] = new Fourchette [5];
        for(int i = 0; i<5; i++) f[i] = new Fourchette();	
        String nom [] = {"Socrate ", "Aristote",  "Epicure ", " Platon ", "Sénèque "};
        Philosophe p[] = new Philosophe [5];
        for(int i = 0; i<5; i++) p[i] = new Philosophe(f[i], f[(i+1)%5], nom[i]);
        System.out.print("Positions à table:");
        for(int i = 0; i<5; i++) System.out.print(" | " + nom[i]);
        System.out.println(" |");
        for(int i = 0; i<5; i++) p[i].start();
    }
}	

class Fourchette {	
    volatile boolean libre = true ;
    synchronized void prendre() {	
        while ( !libre ) {  // Le philosophe s'endort sur la fourchette!
            try { wait(); } catch (InterruptedException e) { e.printStackTrace(); }
        }
        libre = false;      // Cette fourchette n'est plus libre
    }
    synchronized void lâcher() {
        libre = true; 
        notifyAll();        // Réveillons le voisin éventuellement endormi!
    }
}

class Philosophe extends Thread {	
    Fourchette fg;      // La fourchette à gauche
    Fourchette fd;      // La fourchette à droite
    public Philosophe(Fourchette fg, Fourchette fd, String nom){
        this.fg = fg;
        this.fd = fd;
        this.setName(nom);
    }
    public void run(){
        Random aléa = new Random();
        while(true){
            System.out.println("[ " + getName() + " ] Je réfléchis.");
            try { sleep(aléa.nextInt(1000)) ;}
            catch (InterruptedException e) { e.printStackTrace(); }
            System.out.println("[ " + getName() + " ] \t Je suis affamé.");
            fg.prendre(); // Le philosophe prend d'abord la fourchette à gauche
            fd.prendre(); // Puis la fourchette à droite
            System.out.println("[ " + getName() + " ] \t\t Je mange pendant 3s.");
            try { sleep(3000); }
            catch (InterruptedException e) { e.printStackTrace(); }
            System.out.println("[ " + getName() + " ] \t\t\t J'ai bien mangé.");
            fg.lâcher();
            fd.lâcher();
        }
    }	
}
	
/*
  $ javac Diner.java
  $ java Diner
  Positions à table: | Socrate  | Aristote | Epicure  |  Platon  | Sénèque  |
  [ Aristote ] Je réfléchis.
  [ Epicure  ] Je réfléchis.
  [ Sénèque  ] Je réfléchis.
  [  Platon  ] Je réfléchis.
  [ Socrate  ] Je réfléchis.
  [ Aristote ] 	 Je suis affamé.
  [ Aristote ] 		 Je mange pendant 3s.
  [ Epicure  ] 	 Je suis affamé.
  [ Socrate  ] 	 Je suis affamé.
  [  Platon  ] 	 Je suis affamé.
  [  Platon  ] 		 Je mange pendant 3s.
  [ Sénèque  ] 	 Je suis affamé.
  [ Aristote ] 			 J'ai bien mangé.
  [ Aristote ] Je réfléchis.
  [ Socrate  ] 		 Je mange pendant 3s.
  [ Aristote ] 	 Je suis affamé.
  [  Platon  ] 			 J'ai bien mangé.
  [  Platon  ] Je réfléchis.
  [ Epicure  ] 		 Je mange pendant 3s.
  [  Platon  ] 	 Je suis affamé.
  [ Socrate  ] 			 J'ai bien mangé.
  [ Socrate  ] Je réfléchis.
  [ Sénèque  ] 		 Je mange pendant 3s.
  [ Epicure  ] 			 J'ai bien mangé.
  [ Epicure  ] Je réfléchis.
  [ Aristote ] 		 Je mange pendant 3s.
  [ Socrate  ] 	 Je suis affamé.
  [ Epicure  ] 	 Je suis affamé.
  [ Sénèque  ] 			 J'ai bien mangé.
  [ Sénèque  ] Je réfléchis.
  [  Platon  ] 		 Je mange pendant 3s.
  [ Sénèque  ] 	 Je suis affamé.
  [ Aristote ] 			 J'ai bien mangé.
  [ Aristote ] Je réfléchis.
  [ Socrate  ] 		 Je mange pendant 3s.
  [ Aristote ] 	 Je suis affamé.
  ^C
*/
