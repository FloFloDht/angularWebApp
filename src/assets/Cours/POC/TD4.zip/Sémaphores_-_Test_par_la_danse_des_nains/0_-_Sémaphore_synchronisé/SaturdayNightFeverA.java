// -*- coding: utf-8 -*-

import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

/*
  C'est samedi soir, l'heure de danser. Les nains dansent avec Blanche-Neige, mais
  elle ne peut danser qu'avec deux nains à la fois: un sémaphore est utilisé pour
  limiter le nombre de nains qui dansent simultanément avec Blanche-Neige
*/


public class SaturdayNightFeverA {
    
    public static void main(String[] args) throws InterruptedException {
        int nbNains = 7;
        String[] nom = {"Simplet", "Dormeur",  "Atchoum", "Joyeux", "Grincheux", "Prof", "Timide"};
        NainA[] nain = new NainA[nbNains];
        for(int i = 0; i < nbNains; i++) nain[i] = new NainA(nom[i]);
        for(int i = 0; i < nbNains; i++) nain[i].start();
        // for(int i = 0; i < nbNains; i++) nain[i].join();
        // System.out.println("C'est fini.");        
    }
}    

class NainA extends Thread {
    static final MonSémaphoreA blancheNeige = new MonSémaphoreA(2);
    static final List<String> danseurs = Collections.synchronizedList(new ArrayList<String>());
    public NainA(String nom) {
        this.setName(nom);
    }
    public void run() {
        Random aléa = new Random() ;
        while(true) {
            try {
                sleep(aléa.nextInt(1000));
            } catch (InterruptedException e) {e.printStackTrace();}
            System.out.println(getName() + " souhaite danser avec Blanche-Neige.");
            blancheNeige.P();        // Puis-je danser avec Blanche-Neige?
            synchronized(danseurs){
                System.out.println(getName() + " danse avec Blanche-Neige.");
                danseurs.add(getName());
                System.out.println(danseurs);
            }
            try {
                sleep(1000);
            } catch (InterruptedException e) {e.printStackTrace();}
            synchronized(danseurs){
                System.out.println(getName() + " va se reposer un peu.");
                danseurs.remove(getName());
                System.out.println(danseurs);
            }
            blancheNeige.V();        // Vas-y, à ton tour!
        }
        // System.out.println(getName() + " a terminé!");
    }	
}


class MonSémaphoreA {
    private int nbTickets;

    MonSémaphoreA (int n) {
        if ( n<0 ) throw new IllegalArgumentException("Valeur initiale < 0");    
        nbTickets = n;
    }
    
    synchronized void P(){	
        while ( nbTickets <1 ) {
            try {
                wait();       // Il faut attendre un ticket pour danser
            } catch (InterruptedException e) { e.printStackTrace(); }
        }
        nbTickets--;
    }
    
    synchronized void V(){
        nbTickets++;
        notifyAll();   // Réveil de quiconque attend à ticket
    }
}

/*
  $ java SaturdayNightFever
  Grincheux souhaite danser avec Blanche-Neige.
  Grincheux danse avec Blanche-Neige.
  [Grincheux]
  Dormeur souhaite danser avec Blanche-Neige.
  Dormeur danse avec Blanche-Neige.
  [Grincheux, Dormeur]
  Joyeux souhaite danser avec Blanche-Neige.
  Atchoum souhaite danser avec Blanche-Neige.
  Prof souhaite danser avec Blanche-Neige.
  Timide souhaite danser avec Blanche-Neige.
  Simplet souhaite danser avec Blanche-Neige.
  Grincheux va se reposer un peu.
  [Dormeur]
  Joyeux danse avec Blanche-Neige.
  [Dormeur, Joyeux]
  Dormeur va se reposer un peu.
  [Joyeux]
  Simplet danse avec Blanche-Neige.
  [Joyeux, Simplet]
  Grincheux souhaite danser avec Blanche-Neige.
  Dormeur souhaite danser avec Blanche-Neige.
  Joyeux va se reposer un peu.
  [Simplet]
  Atchoum danse avec Blanche-Neige.
  ^C
  $
*/

