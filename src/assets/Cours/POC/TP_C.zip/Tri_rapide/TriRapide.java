// -*- coding: utf-8 -*-

import java.util.Random ;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

public class TriRapide {
	static final int taille = 70_000_000 ;                   // Longueur du tableau a trier
	static final int [] tableauSeq = new int[taille] ;         // Le tableau d'entiers a trier de facon sequentiel
	static final int [] tableauPar = new int[taille] ;		//tableau d'entier a trier de facon parallele
	static final int borne = 10 * taille ;                  // Valeur maximale dans le tableau

	private static void echangerElements(int[] t, int m, int n) {
		int temp = t[m] ;
		t[m] = t[n] ;
		t[n] = temp ;
	}

	private static int partitionner(int[] t, int debut, int fin) {
		int v = t[fin] ;                               // Choix (arbitraire) du pivot : t[fin]
		int place = debut ;                            // Place du pivot, a droite des elements deplaces
		for (int i = debut ; i<fin ; i++) {            // Parcours du *reste* du tableau
			if (t[i] < v) {                            // Cette valeur t[i] doit etre a droite du pivot
				echangerElements(t, i, place) ;        // On le place a sa place
				place++ ;                              // On met a jour la place du pivot
			}
		}
		echangerElements(t, place, fin) ;              // Placement definitif du pivot
		return place ;
	}

	private static void triRapideSequentielle(int[] t, int debut, int fin) {
		if (debut < fin) {                             // S'il y a un seul element, il n'y a rien a faire!
			int p = partitionner(t, debut, fin) ;
			triRapideSequentielle(t, debut, p-1) ;
			triRapideSequentielle(t, p+1, fin) ;
		}
	}

	private static void afficher(int[] t, int debut, int fin) {
		for (int i = debut ; i <= debut+3 ; i++) {
			System.out.print(" " + t[i]) ;
		}
		System.out.print("...") ;
		for (int i = fin-3 ; i <= fin ; i++) {
			System.out.print(" " + t[i]) ;
		}
		System.out.println() ;
	}


	/**
	 * Classe de tri rapide de facon parallele avec un ForkJoinPool
	 * si taille du sous tableau est supérieur à 1000 alors on fait un tri parallele
	 * sinon il sera effectuer en sequentielle
	 */
	static class TriRapideParallele extends RecursiveAction {
		int [] tableauPar;  
		int debut;
		int fin;

		public TriRapideParallele(int[] t, int debut, int fin) {
			this.tableauPar=t;
			this.debut = debut;
			this.fin = fin;
		}

		@Override		//methode qui permet le tri de façon parallèle
		protected void compute() {   
			if (fin - debut < 1000) {	
				triRapideSequentielle(tableauPar,debut,fin);
			}
			else {
				int p = partitionner(tableauPar,debut,fin);
				invokeAll(new TriRapideParallele(tableauPar, debut, p-1), new TriRapideParallele(tableauPar, p + 1, fin)); //execute le tri des sous tableaux de façon parrallele
			}
		}
	}

	/**
	* methode permettant de comparer si 2 tableaux sont identiques,
	* supposé de longueur 'taille'
	*/

	public static void comparer(int[] tab1, int[] tab2){  
		for (int i = 0; i<taille; i++){
			if(tab1[i] != tab2[i]){
				System.out.println("Tris non cohérents");
			}
		}
		System.out.println("Les tris sont cohérents");
	}

	/**
	*	Methode Main()
	*/

	public static void main(String[] args) {
		Random alea = new Random() ;

		for (int i=0 ; i<taille ; i++) {                          // Remplissage aleatoire du tableau sequentiel
			tableauSeq[i] = alea.nextInt(2*borne) - borne ;
			tableauPar[i] = tableauSeq[i];
		}

		System.out.print("Tableau initial : ") ;
		afficher(tableauSeq, 0, taille -1);                         // Affiche le tableau a trier

		System.out.println();

		System.out.println("Démarrage du tri rapide séquentiel :") ;
		long debutTriSeq = System.nanoTime();

		triRapideSequentielle(tableauSeq, 0, taille-1) ;                   // Tri du tableau sequentielle
		long finDuTriSeq = System.nanoTime();

		long dureeDuTriSeq = (finDuTriSeq - debutTriSeq) / 1_000_000 ;
		System.out.print("Tableau trié : ") ;
		afficher(tableauSeq, 0, taille -1) ;
		System.out.println("Version séquentiel :" + dureeDuTriSeq + " ms.");

		System.out.println();

		System.out.println("Démarrage du tri rapide parallele : ") ;
		long debutTriPar = System.nanoTime();

		ForkJoinPool pool = new ForkJoinPool(4); 	//limitation du nombre de threads utilisé à 4 
		pool.invoke(new TriRapideParallele(tableauPar, 0, taille-1));	//demarre le tri rapide parrallele 

		long finDuTriPar = System.nanoTime();
		long dureeDuTriPar = (finDuTriPar - debutTriPar) / 1_000_000 ;
		System.out.print("Tableau trié : ") ;
		afficher(tableauSeq, 0, taille-1);
		System.out.println("Version parallèle :" + dureeDuTriPar + " ms.");// Affiche le tableau obtenu
		
		System.out.println("Gain obsersé : "  + (double)(dureeDuTriSeq - dureeDuTriPar)/1000  + " s");

		comparer(tableauPar, tableauSeq);
	}
}


/* Affichage d'une execution du code : 
root@ZenBookFLo:/mnt/c/Users/FloFlo-PC/Desktop/POC/TP/TP_C/Tri_rapide# make
javac *.java
root@ZenBookFLo:/mnt/c/Users/FloFlo-PC/Desktop/POC/TP/TP_C/Tri_rapide# java TriRapide
Tableau initial :  314315102 62944517 247892697 484057054... -192637826 569149732 558790467 418934193

Démarrage du tri rapide séquentiel :
Tableau trié :  -699999975 -699999937 -699999913 -699999868... 699999934 699999948 699999964 699999996
Version séquentiel :9405 ms.

Démarrage du tri rapide parallele :
Tableau trié : -699999975 -699999937 -699999913 -699999868... 699999934 699999948 699999964 699999996
Version parallèle :3582 ms.
Gain obsersé : 5.823 s
Les tris sont cohérents
*/

