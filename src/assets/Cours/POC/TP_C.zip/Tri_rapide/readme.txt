 
CARMONA Aymeric & DHONT Florent  
 
Affichage d'une execution du code : 

root@ZenBookFLo:/mnt/c/Users/FloFlo-PC/Desktop/POC/TP/TP_C/Tri_rapide# make
javac *.java
root@ZenBookFLo:/mnt/c/Users/FloFlo-PC/Desktop/POC/TP/TP_C/Tri_rapide# java TriRapide
Tableau initial :  314315102 62944517 247892697 484057054... -192637826 569149732 558790467 418934193

Démarrage du tri rapide séquentiel :
Tableau trié :  -699999975 -699999937 -699999913 -699999868... 699999934 699999948 699999964 699999996
Version séquentiel :9405 ms.

Démarrage du tri rapide parallele :
Tableau trié : -699999975 -699999937 -699999913 -699999868... 699999934 699999948 699999964 699999996
Version parallèle :3582 ms.
Gain obsersé : 5.823 s
Les tris sont cohérents


 
Exécution sur machine de Florent : 

Spécification machine :
4 coeurs
8 processeurs logiques
Vitesse de base : 1.80 GHz
8 Go de memoire vive disponible
