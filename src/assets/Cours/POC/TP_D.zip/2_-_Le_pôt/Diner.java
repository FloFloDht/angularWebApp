// -*- coding: utf-8 -*-

import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Diner {
    public static void main(String args[]) {
        int nbSauvages = 10;               // La tribu comporte 10 sauvages affamés
        int nbPortions = 3;                // Le pôt contient 3 parts, lorsqu'il est rempli
        System.out.println("Il y a " + nbSauvages + " sauvages.");
        System.out.println("Le pôt peut contenir "+ nbPortions + " portions.");
        Pôt pôt = new Pôt(nbPortions);
        new Cuisinier(pôt).start();
        for (int i = 0; i < nbSauvages; i++) {
            new Sauvage(pôt, i).start();
        }
        for(int i = 0; i < 1_000_000; i++){
            synchronized(pôt){pôt.notifyAll();}
            try{ Thread.sleep(100);
            } catch(InterruptedException e ) {break; };
        }
    } // CE PROGRAMME N'EST PAS SENSÉ TERMINER !
}  

class Sauvage extends Thread {
    public Pôt pôt;
    Random aléa = new Random();
    public Sauvage(Pôt pôt, int numéro) {
        this.pôt = pôt ; 
        this.setName("S" + numéro) ;
    }
    public void run() {
        while (true) {
            try {
                Thread.sleep(aléa.nextInt(5_000));
                System.out.println(getName() + ": J'ai faim!");
                pôt.seServir();
            } catch (InterruptedException e) { break; }; 
        }
    }
}

class Cuisinier extends Thread {
    public Pôt pôt;
    public Cuisinier(Pôt pôt) {
        this.pôt = pôt ;
        this.setName("Cuisinier") ;
    }
    public void run() {
        while(true){
            try {
                pôt.remplir();
            } catch (InterruptedException e) { break; }; 
        }
    }
}

class Pôt {
    private volatile int nbPortions;
    private final int volume;
    private volatile int nbSauvagesAffames = 0;
    // private ReentrantLock louche = new ReentrantLock(true);
    // La louche est libre au départ

    public Pôt(int nbPortions) {
		this.volume = nbPortions;
		this.nbPortions = nbPortions;
	}

	synchronized public boolean estVide() {
		return (nbPortions == 0); 
	}

	synchronized public void remplir() throws InterruptedException {		
		while( nbSauvagesAffames == 0 || ! estVide() ) {  // Tant que le pôt n'est pas vide, je ne le remplis pas.
			wait();
		}
		System.out.println("Cuisinier: Je cuisine...");
        Thread.sleep(2000);
		nbPortions = volume;
		System.out.println("Cuisinier: Le pôt est plein!");
		notifyAll();
	}   

	synchronized public void seServir() throws InterruptedException {
        // louche.lock();
        // System.out.println("\t" + Thread.currentThread().getName()
        //                   + ": Je prends la louche.");
		if ( ! estVide() ) {
            System.out.println("\t" + Thread.currentThread().getName() + ": Il y a une part disponible ! ");
        } else { // Le pôt est vide: on réveille le cuisinier
			System.out.println("\t" + Thread.currentThread().getName() + ": Le pôt est vide!");
			System.out.println("\t\t" + Thread.currentThread().getName() + ": Je réveille le cuisinier.");
			nbSauvagesAffames ++;
            notifyAll();
			System.out.println("\t\t" + Thread.currentThread().getName() + ": J'attends que le pôt soit plein!");
            while ( estVide() ) { // Tant que le pôt est vide, je ne me sers pas.
                wait();
            }
			System.out.println("\t\t" + Thread.currentThread().getName() + ": Je me réveille! Je me sers.");
            nbSauvagesAffames --;
        }
		nbPortions--;
        // System.out.println("\t" + Thread.currentThread().getName()
        //                    + ": Je pose la louche.");
        // louche.unlock();
	}    
}


/*
  $ java Diner
  Il y a 10 sauvages.
  Le pôt peut contenir 3 portions.
  S0: J'ai faim!
  ....S0: Il y a une part disponible ! 
  S2: J'ai faim!
  ....S2: Il y a une part disponible ! 
  S9: J'ai faim!
  ....S9: Il y a une part disponible ! 
  S6: J'ai faim!
  ....S6: Le pôt est vide!
  ........S6: Je réveille le cuisinier.
  ........S6: J'attends que le pôt soit plein!
  Cuisinier: Je cuisine...
  S7: J'ai faim!
  S5: J'ai faim!
  S2: J'ai faim!
  S8: J'ai faim!
  S4: J'ai faim!
  Cuisinier: Le pôt est plein!
  ........S6: Je me réveille! Je me sers.
  ....S4: Il y a une part disponible ! 
  ....S8: Il y a une part disponible ! 
  ....S2: Le pôt est vide!
  ........S2: Je réveille le cuisinier.
  ........S2: J'attends que le pôt soit plein!
  ....S5: Le pôt est vide!
  ........S5: Je réveille le cuisinier.
  ........S5: J'attends que le pôt soit plein!
  ....S7: Le pôt est vide!
  ........S7: Je réveille le cuisinier.
  ........S7: J'attends que le pôt soit plein!
  Cuisinier: Je cuisine...
  S4: J'ai faim!
  S1: J'ai faim!
  S9: J'ai faim!
  S0: J'ai faim!
  S8: J'ai faim!
  S6: J'ai faim!
  S3: J'ai faim!
  Cuisinier: Le pôt est plein!
  ........S7: Je me réveille! Je me sers.
  ........S2: Je me réveille! Je me sers.
  ........S5: Je me réveille! Je me sers.
  ....S3: Le pôt est vide!
  ^C$
*/
