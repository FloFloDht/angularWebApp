Voici une démonstration d'une compilation et exécution de notre Programme : 

root@ZenBookFLo:/mnt/c/Users/FloFlo-PC/Desktop/POC/TP/TP_D/3_-_Le_retour_des_babouins# make
javac *.java
root@ZenBookFLo:/mnt/c/Users/FloFlo-PC/Desktop/POC/TP/TP_D/3_-_Le_retour_des_babouins# java Babouin
Le babouin E1 arrive sur le côté EST
         Le babouin E1 commence à traverser.
Le babouin O2 arrive sur le côté OUEST
Le babouin E3 arrive sur le côté EST
         Le babouin E3 commence à traverser.
                 Le babouin E1 a terminé sa traversée.
Le babouin E4 arrive sur le côté EST
         Le babouin E4 commence à traverser.
Le babouin E5 arrive sur le côté EST
         Le babouin E5 commence à traverser.
                 Le babouin E3 a terminé sa traversée.
Le babouin O6 arrive sur le côté OUEST
                 Le babouin E4 a terminé sa traversée.
Le babouin O7 arrive sur le côté OUEST
                 Le babouin E5 a terminé sa traversée.
         Le babouin O6 commence à traverser.
         Le babouin O7 commence à traverser.
         Le babouin O2 commence à traverser.
Le babouin O8 arrive sur le côté OUEST
         Le babouin O8 commence à traverser.
Le babouin E9 arrive sur le côté EST
                 Le babouin O2 a terminé sa traversée.
                 Le babouin O7 a terminé sa traversée.
                 Le babouin O6 a terminé sa traversée.
Le babouin O10 arrive sur le côté OUEST
         Le babouin O10 commence à traverser.
                 Le babouin O8 a terminé sa traversée.
Le babouin O11 arrive sur le côté OUEST
         Le babouin O11 commence à traverser.
Le babouin E12 arrive sur le côté EST
                 Le babouin O10 a terminé sa traversée.
Le babouin O13 arrive sur le côté OUEST
         Le babouin O13 commence à traverser.
                 Le babouin O11 a terminé sa traversée.
Le babouin O14 arrive sur le côté OUEST
         Le babouin O14 commence à traverser.
Le babouin O15 arrive sur le côté OUEST
         Le babouin O15 commence à traverser.
                 Le babouin O13 a terminé sa traversée.
Le babouin O16 arrive sur le côté OUEST
         Le babouin O16 commence à traverser.
                 Le babouin O14 a terminé sa traversée.
Le babouin O17 arrive sur le côté OUEST
         Le babouin O17 commence à traverser.
                 Le babouin O15 a terminé sa traversée.
Le babouin O18 arrive sur le côté OUEST
         Le babouin O18 commence à traverser.
                 Le babouin O16 a terminé sa traversée.
Le babouin O19 arrive sur le côté OUEST
         Le babouin O19 commence à traverser.
                 Le babouin O17 a terminé sa traversée.
                 Le babouin O18 a terminé sa traversée.
                 Le babouin O19 a terminé sa traversée.
         Le babouin E9 commence à traverser.
         Le babouin E12 commence à traverser.
                 Le babouin E12 a terminé sa traversée.
                 Le babouin E9 a terminé sa traversée.
root@ZenBookFLo:/mnt/c/Users/FloFlo-PC/Desktop/POC/TP/TP_D/3_-_Le_retour_des_babouins#