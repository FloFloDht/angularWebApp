import java.util.concurrent.atomic.AtomicLong; 
//-*- coding: utf-8 -*-

enum Côté { EST, OUEST }                  // Le canyon possède un côté EST et un côté OUEST

class Babouin extends Thread{
	private final Côté origine;           // Côté du canyon où apparaît le babouin: EST ou OUEST
	private static final Corde corde = new Corde();  // Corde utilisée par tous les babouins

	Babouin(Côté origine, int i) {        // Constructeur de la classe Babouin
		this.origine = origine;           // Chaque babouin apparaît d'un côté précis du canyon
		if (origine == Côté.EST) setName("E"+i);
		else setName("O"+i);
	}
	public Côté origine() {
		return origine ;
	}

	public void run() {
		System.out.println("Le babouin " + getName() + " arrive sur le côté " + origine);
		try {
			corde.saisir();                       // Pour traverser, le babouin saisit la corde
		} catch(InterruptedException e){e.printStackTrace();}
		System.out.println("\t Le babouin " + getName() + " commence à traverser.");
		try {
			sleep(5000);                                 // La traversée ne dure que 5 secondes
		} catch(InterruptedException e){e.printStackTrace();}
		System.out.println("\t\t Le babouin " + getName() + " a terminé sa traversée.");
		corde.lâcher();                    // Arrivé de l'autre côté, le babouin lâche la corde
	}

	public static void main(String[] args) { 
		for (int i = 1; i < 20; i++){
			try { Thread.sleep(2000); } catch(InterruptedException e){e.printStackTrace();}	
			if (Math.random() >= 0.5){
				new Babouin(Côté.EST, i).start();          // Création d'un babouin à l'est
			} else {
				new Babouin(Côté.OUEST, i).start();      // Création d'un babouin à l'ouest
			}
		} // Une vingtaine de babouins sont répartis sur les deux côtés du canyon
	}
}

/**
 * uniquement cette classe à modifier !! 
 */

class Corde {
	private final AtomicLong nbEntréesOuest = new AtomicLong(0);
	private final AtomicLong nbEntréesEst = new AtomicLong(0);

	public void saisir() throws InterruptedException {
		Babouin courant = (Babouin) Thread.currentThread() ;
		Côté origine = courant.origine() ;
		int cordeAquise=0;						//teste permettant de savoir si le babouins à deja la corde en main
		while(cordeAquise==0) {
			int copieEntréesEst=(int)nbEntréesEst.get();
			int copieEntréesOuest=(int)nbEntréesOuest.get();
			if (origine == Côté.EST) {
				if(copieEntréesOuest == 0 && copieEntréesEst < 5) {
					int prochainEst= copieEntréesEst+1;
					if(nbEntréesEst.compareAndSet(copieEntréesEst, prochainEst)) {cordeAquise=1;}
				}
			} else {
				if(copieEntréesOuest < 5 && copieEntréesEst == 0) {
					int prochainOuest= copieEntréesOuest+1;
					if(nbEntréesOuest.compareAndSet(copieEntréesOuest, prochainOuest)) {cordeAquise=1;}
				}
			}
		}
	}
	public void lâcher() {
		Babouin courant = (Babouin) Thread.currentThread() ;
		Côté origine = courant.origine() ;
		if (origine == Côté.EST) {
			nbEntréesEst.set(nbEntréesEst.get()-1);
		} else {
			nbEntréesOuest.set(nbEntréesOuest.get()-1);
		}
	}
}


