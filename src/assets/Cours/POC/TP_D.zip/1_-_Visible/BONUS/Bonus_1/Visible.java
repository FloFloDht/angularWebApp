public class Visible {
    public static void main(String[] args) throws Exception {
        A a = new A() ;        // Création d'un objet a de la classe A
        a.start() ;            // Lancement du thread a
        Thread.sleep(500) ;
        a.fin = true ;         // Modification de l'attribut fin
        System.out.println("Le main a mis la variable \"fin\" à \"vrai\".") ;      
    }  
} 

class A extends Thread {
    public boolean fin = false ;    
    public void run() {
        while(! fin) {
            // System.out.print("") ;      
        } ;   
        System.out.println("Le thread A termine...") ;      
    }      
}  

/* Sans l'instruction print() dans le boucle d'attente active
  $ make
  javac *.java
  $ java Visible
  Le main a mis la variable "fin" à "vrai".
  ^C$ 
*/

/* Avec l'instruction print()
  $ make
  javac *.java
  $ java Visible
  Le main a mis la variable "fin" à "vrai".
  Le thread A termine...
  $ 
*/
