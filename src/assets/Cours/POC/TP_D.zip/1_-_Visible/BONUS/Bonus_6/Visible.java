public class Visible {
    static final int taille = 1;
    static boolean[] fin = new boolean[taille];

    public static void main(String[] args) throws Exception {
        for (int i=0; i< taille; i++) fin[i] = false ;
        A a = new A() ;             // Création d'un objet a de la classe A
        a.start() ;                 // Lancement du thread a
        Thread.sleep(1000) ;
        System.out.println("Le main met le tableau \"fin\" à \"vrai\"...") ;      
        for (int i=0; i< taille; i++) fin[i] = true ;
        Thread.sleep(2000) ;
        System.out.println("Le main interrompt le thread A.") ;      
        a.interrupt();
    }  
    static class A extends Thread { // Classe interne
        public void run() {
            while(! fin[0]) {
            }
            if (interrupted()) {
                System.out.println("Le thread A a été interrompu!") ;
            }
            System.out.println("Le thread A termine...") ;      
        }    
    } 
} 


/* Sans yield() pendant l'attente active
   $ java Visible
   Le main a mis la variable "fin" à "vrai".
   ^C
*/

/* Avec yield() pendant l'attente active
   $ java Visible
   Le main a mis la variable "fin" à "vrai".
   Le thread A termine...
*/

