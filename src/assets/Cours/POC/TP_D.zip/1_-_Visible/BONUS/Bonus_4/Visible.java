public class Visible {
    static boolean fin = false ;    
    public static void main(String[] args) throws Exception {
        A a = new A() ;             // Création d'un objet a de la classe A
        a.start() ;                 // Lancement du thread a
        Thread.sleep(1000) ;
        fin = true ;                // Modification de l'attribut statique fin
        System.out.println("Le main a mis la variable \"fin\" à \"vrai\".") ;      
    }  
    static class A extends Thread { // Classe interne
        public void run() {
            while(! fin) {          // Attente active
                // yield() ;
            } ;    
            System.out.println("Le thread A termine...") ;      
        }      
    }  
} 


/* Sans yield() pendant l'attente active
   $ java Visible
   Le main a mis la variable "fin" à "vrai".
   ^C
*/

/* Avec yield() pendant l'attente active
   $ java Visible
   Le main a mis la variable "fin" à "vrai".
   Le thread A termine...
*/

