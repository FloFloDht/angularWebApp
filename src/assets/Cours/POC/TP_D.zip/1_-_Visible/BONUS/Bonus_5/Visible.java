public class Visible {
    static boolean fin = false;

    public static void main(String[] args) throws Exception {
        A a = new A() ;             // Création d'un objet a de la classe A
        a.start() ;                 // Lancement du thread a
        Thread.sleep(1000) ;
        System.out.println("Le main met \"fin\" à \"vrai\"...") ;      
        fin = true;
    }  
    static class A extends Thread { // Classe interne
        public void run() {
            while(! fin) {
                // if (interrupted()) {
                //    System.out.println("Le thread A a été interrompu!") ;
                //    break;
                // }
            }
            System.out.println("Le thread A termine...") ;      
        }    
    } 
} 


/* Le code ci-dessus donne sur ma machine une exécution d'une seconde:
   $ java Visible
   Le main met "fin" à "vrai"...
   Le thread A termine...
*/

/* En supprimant le if de l'attente active, j'obtiens un exécution bloquée:
   $ java Visible
   Le main met "fin" à "vrai"...
   ^C
*/

