import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SeptNains {
    static private SimpleDateFormat sdf = new SimpleDateFormat("hh'h 'mm'mn 'ss','SSS's'");
    
    public static void main(String[] args) throws InterruptedException {
        Date début = new Date(System.currentTimeMillis());
        System.out.println("[" + sdf.format(début) + "] Début du programme.");
        
        final BlancheNeige bn = new BlancheNeige();
        final int nbNains = 7;
        final String noms [] = {"Simplet", "Dormeur",  "Atchoum", "Joyeux", "Grincheux",
                "Prof", "Timide"};
        final Nain nain [] = new Nain [nbNains];
        for(int i = 0; i < nbNains; i++) nain[i] = new Nain(noms[i],bn);
        for(int i = 0; i < nbNains; i++) nain[i].start();
        Thread.sleep(5000);     //interruption de chaucun des 7 nains avec methos intterrupted() au bout de 5s
        for(int i = 0; i < nbNains; i++) nain[i].interrupt();
        for (int i = 0; i < nbNains; i++) nain[i].join();
        System.out.println("[" + sdf.format(début) + "] Tous les nains ont terminé.");
    }
}

class BlancheNeige {
    private volatile boolean libre = true;              // Initialement, Blanche-Neige est libre.
    ArrayList<String> fileAttente = new ArrayList<>();  //faire la liste d'attente (arrayList String pour les noms)
    public synchronized void requérir () {
        //add nains dans arrayList
        fileAttente.add(Thread.currentThread().getName());
        System.out.println("\t" + Thread.currentThread().getName()
                + " veut la ressource.");
    }
    
    public synchronized void accéder () throws InterruptedException {
        //on veut que bn pas libre et que nain pas en tete de file pour sortir de la boucle, donc ici bn n'est pas libre ou nain pas en tete de liste
        while ( ! libre || !(fileAttente.get(0).equals(Thread.currentThread().getName()))) wait();            // Le nain s'endort sur l'objet bn
        libre = false;
        fileAttente.remove(Thread.currentThread().getName());   //supprimer le nain de la file d'attente
        System.out.println("\t" + Thread.currentThread().getName()
                + " accède à la ressource.");
    }
    
    public synchronized void relâcher () {
        System.out.println("\t" + Thread.currentThread().getName()
                + " relâche la ressource.");
        libre = true;
        notifyAll();
    }
}

class Nain extends Thread {
    static private SimpleDateFormat sdf = new SimpleDateFormat("hh'h 'mm'mn 'ss','SSS's'");
    private BlancheNeige bn;
    public Nain(String nom, BlancheNeige bn) {
        this.setName(nom);
        this.bn = bn;
    }
    public void run() {
        while(true) {
            bn.requérir();
            try { bn.accéder(); } catch (InterruptedException e) {
                System.out.println(getName() + " dit adieu");
                break;      //break pour arreter le thread en cours et terminer le programme
            }
            Date heureActuelle = new Date(System.currentTimeMillis());
            System.out.println("[" + sdf.format(heureActuelle) + "] " + getName() + " a un accès (exclusif) à Blanche-Neige.");
            long time = 0;
            try {
                time = System.currentTimeMillis();
                sleep(2000);} catch (InterruptedException e) {
                try {
                    sleep(2000-(System.currentTimeMillis()-time));
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
                System.out.println(getName() + " dit adieu");
                break;      //break pour arreter le thread en cours et terminer le programme
            }
            System.out.println("[" + sdf.format(heureActuelle) + "] " + getName() + " s'apprête à quitter Blanche-Neige.");
            bn.relâcher();
        }
        Date fin = new Date(System.currentTimeMillis());
        System.out.println("[" + sdf.format(fin) + "] " + getName() + " a terminé !");
    }
}
